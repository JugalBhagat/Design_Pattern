package Command_DP;

public class tubelightON implements command {
	tubelight tl;
	public tubelightON(tubelight tl) {
		this.tl=tl;
	}
	@Override
	public void execute() {
		tl.switchON();
	}

}
