package Command_DP;

public class tubelight {
	void switchON() {
		System.out.println("Tube Light ON");
	}
	void switchOFF() {
		System.out.println("Tube Light OFF");
	}
}
