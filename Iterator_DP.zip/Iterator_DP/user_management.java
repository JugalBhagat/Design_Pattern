package Iterator_DP;

import java.util.ArrayList;

public class user_management {
	ArrayList<user> ul =new ArrayList<>();
	public void add_user(user u)
	{
		ul.add(u);
	}
	public user get_user(int index)
	{
		return ul.get(index);
	}
	
	public My_iterator getIterator() {
		return new My_iterator_impl(ul);
	}
	
}
