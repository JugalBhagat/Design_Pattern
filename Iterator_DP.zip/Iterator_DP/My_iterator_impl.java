package Iterator_DP;

import java.util.ArrayList;
import java.util.List;

public class My_iterator_impl implements My_iterator {

	private int pos=0;
	private List<user> user_list;
	private int len;
	public My_iterator_impl(ArrayList<user> list) {
		this.user_list=list;
		this.len=list.size();
	}

	@Override
	public boolean hasNext() {
		if(pos < len )
			return true;
		else
			return false;
	}

	@Override
	public user Next() {
		user u=user_list.get(pos);
		pos+=1;
		return u;
	}

}
