package Iterator_DP;

public class main_class {

	public static void main(String[] args) {
		
		user_management um=new user_management();
		um.add_user(new user("jugal","1"));
		um.add_user(new user("satish","2"));
		um.add_user(new user("pallavi","3"));
		um.add_user(new user("bhagat","4"));
		
		My_iterator myi=um.getIterator();
		while(myi.hasNext()) {
			user u=myi.Next();
			System.out.print(u.getname() + " - ");
			System.out.println(u.getid());
		}

	}

}
