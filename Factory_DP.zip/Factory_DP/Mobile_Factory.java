package Factory_DP;

public class Mobile_Factory {
	
	public Mobile create_mobile(String brand)
	{
		if("Iphone".equals(brand))
			return new Iphone();
		else if("Samsung".equals(brand))
			return new Iphone();
		else if("OnePlus".equals(brand))
			return new Iphone();
		else
			return null;
	}
}
