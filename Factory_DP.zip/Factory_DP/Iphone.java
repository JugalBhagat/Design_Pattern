package Factory_DP;

public class Iphone implements Mobile {

	@Override
	public void createmobile() {
		// TODO Auto-generated method stub
		System.out.println("Apple creating mobiles");
		
	}

}