package Factory_DP;

public class Oneplus implements Mobile {

	@Override
	public void createmobile() {
		// TODO Auto-generated method stub
		System.out.println("Oneplus creating mobiles");
		
	}

}
