package Factory_DP;

interface Mobile {
	public void createmobile();
}
