package State_DP;

public class type_silver implements Bank{

	@Override
	public void getbenifits() {
		System.out.println("Silver benifits Activated");	
	}
	
}
