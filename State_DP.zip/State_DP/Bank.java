package State_DP;

interface Bank {
	public void getbenifits();
}
