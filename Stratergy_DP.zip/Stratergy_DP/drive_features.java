package Stratergy_DP;

interface drive_features {
	public void feature();
}
