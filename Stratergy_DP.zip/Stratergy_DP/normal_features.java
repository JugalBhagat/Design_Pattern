package Stratergy_DP;

public class normal_features implements drive_features {

	@Override
	public void feature() {
		System.out.println("normal features");
	}

}
