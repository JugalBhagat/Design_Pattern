package Facade_DP;

public class Sound_SYS {
	public void ss_on(){
		System.out.println("Sound system on....");
	}
	public void ss_off(){
		System.out.println("Sound system off....");
	}
}
