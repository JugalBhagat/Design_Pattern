package Adapter_DP;

public class Json_Software implements Json_Data {
	
	

	@Override
	public void read_json_data() {
		
		System.out.println("Reading Json Data .......");
		
	}

}
