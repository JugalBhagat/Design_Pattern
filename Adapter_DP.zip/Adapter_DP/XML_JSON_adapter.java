package Adapter_DP;

public class XML_JSON_adapter implements Json_Data {
	XML_data x_data;
	public XML_JSON_adapter(XML_data x_data)
	{
		this.x_data=x_data;
	}
	@Override
	public void read_json_data() {
		x_data.read_xml_data();
	}
	
}
