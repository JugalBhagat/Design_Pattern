package Adapter_DP;

interface XML_data {
	void read_xml_data();
}
