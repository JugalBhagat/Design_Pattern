package Adapter_DP;

public class main_class {

	public static void main(String[] args) {
		
		XML_Software x_data=new XML_Software();
		Json_Data jd=new XML_JSON_adapter(x_data);
		jd.read_json_data();
	}

}
