package Observer_DP;

public class weather_station {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		weather_data wd= new weather_data();
		
		forcast_display fd=new forcast_display();
		statical_display sd=new statical_display();
		
		wd.attach(fd);
		
		double temperature=24.5;
		double humidity=70.5;
		double pressure=2000.5;

		wd.set_mesurement(temperature, humidity, pressure);
		
		wd.detach(fd);
		
		wd.set_mesurement(temperature, humidity, pressure);
		
		wd.attach(sd);
		
		temperature=46.5;
		humidity=90.5;
		pressure=1200.5;
		
		wd.set_mesurement(temperature, humidity, pressure);
		
		//weather_data weatherData = new weather_data();
		double temp = wd.get_temp();
		double humd = wd.get_humd();
		double pres = wd.get_pres();
		
		System.out.println("\nCurrent Weatherdata");
		
		System.out.println("temp : "+temp);
		System.out.println("humd : "+humd);
		System.out.println("pres : "+pres);

	}

}
