package Observer_DP;

public class forcast_display implements observer{

	@Override
	public void update(double temp, double humd, double pres) {
		System.out.println("\nForecast Display:");
        System.out.println("Temperature: " + temp);
        System.out.println("Humidity: " + humd);
        System.out.println("Pressure: " + pres);
		
	}
	public String tostr()
	{
		return "forcast_obj";
	}

}
