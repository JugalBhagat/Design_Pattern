package State_DP;

public class Account {
	private Bank state;
	private int balance;
	public Account(){
		state=new type_silver();
	}
	void deposite(int amt){
		balance+=amt;
		System.out.println("balance : "+balance);
		evaluate_type();
	}
	void withdraw(int amt)
	{
		if(balance > amt)
		{
			balance-=amt;
			evaluate_type();
		}
		System.out.println("balance : "+balance);
	}
	void evaluate_type()
	{
		if(balance > 10000)
			state= new type_platinum();
		else if(balance > 5000)
			state = new type_gold();
		else
			state = new type_silver();
	}
	void get_current_benifits()
	{
		state.getbenifits();
	}
}
