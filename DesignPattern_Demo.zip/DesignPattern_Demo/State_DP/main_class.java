package State_DP;

public class main_class {
	public static void main(String args[]) {
		Account a=new Account();
		
		a.deposite(1000);
		a.get_current_benifits();
		a.deposite(100000);
		a.get_current_benifits();
	}
}
