package State_DP;

public class type_platinum implements Bank{

	@Override
	public void getbenifits() {
		System.out.println("Platinum benifits Activated");	
	}
	
}
