package State_DP;

public class type_gold implements Bank{

	@Override
	public void getbenifits() {
		System.out.println("Gold benifits Activated");	
	}
	
}
