/**
 * 
 */
/**
 * 
 */
module Design_patterns {
}