package Singleton_DP;

public class main_class {

	public static void main(String[] args) {
		
		Singleton_cls s1=Singleton_cls.getInstance();
		Singleton_cls s2=Singleton_cls.getInstance();
		
		
		System.out.println(s1==s2);
		s1.doSomething();
	}

}
