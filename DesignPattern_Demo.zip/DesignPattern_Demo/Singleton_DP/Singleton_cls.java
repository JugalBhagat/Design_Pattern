package Singleton_DP;

public class Singleton_cls {
	private static Singleton_cls instance;
	Singleton_cls() {
		
	}
	public static Singleton_cls getInstance() {
		if(instance==null)
			instance=new Singleton_cls();
		return instance;
	}
	public void doSomething()
	{
		System.out.print("doSomething is called");
	}
}
