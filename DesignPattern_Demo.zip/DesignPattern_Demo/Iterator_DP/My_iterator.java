package Iterator_DP;

interface My_iterator {
	public boolean hasNext();
	public user Next();
}
