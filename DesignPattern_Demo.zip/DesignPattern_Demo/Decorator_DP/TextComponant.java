package Decorator_DP;

interface TextComponant {
	public String render();
}
