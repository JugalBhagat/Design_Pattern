package Decorator_DP;

public class Bold_text extends Text_Decorator {

	public Bold_text(TextComponant tc) {
		super(tc);
	}
	public String render()
	{
		return "<b>"+super.render()+"</b>";
	}
}
