package Decorator_DP;

abstract class Text_Decorator implements TextComponant {
	TextComponant tc;
	public Text_Decorator(TextComponant tc) {
		this.tc=tc;
	}
	public String render() {
		return tc.render();
	}
}
