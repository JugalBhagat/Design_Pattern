package Factory_DP;

public class main_class {
	public static void main(String args[])
	{
		Mobile_Factory mf=new Mobile_Factory();
		Mobile mobile =mf.create_mobile("Samsung");
		mobile.createmobile();
		
		Mobile mobile2 =mf.create_mobile("Iphone");
		mobile2.createmobile();
		
		Mobile mobile3 =mf.create_mobile("OnePlus");
		mobile3.createmobile();
		
	}
}
