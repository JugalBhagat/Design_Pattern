package Factory_DP;

public class Samsung implements Mobile {

	@Override
	public void createmobile() {
		System.out.println("Samsung creating mobiles");
		
	}

}