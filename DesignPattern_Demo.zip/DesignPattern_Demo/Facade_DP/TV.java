package Facade_DP;

public class TV {
	public void tv_on(){
		System.out.println("TV on....");
	}
	public void tv_off(){
		System.out.println("TV off....");
	}
}
