package Facade_DP;

public class Room_Light {
	public void room_light_on(){
		System.out.println("Room Light on....");
	}
	public void room_light_off(){
		System.out.println("Room Light off....");
	}
}
