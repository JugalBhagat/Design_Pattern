package Facade_DP;

public class main_class {

	public static void main(String[] args) {
		TV tv=new TV();
		Sound_SYS ss=new Sound_SYS();
		Room_Light rl=new Room_Light();
		fecade_HomeTheater f=new fecade_HomeTheater(tv,ss,rl); 
		f.watch_movie();
		f.stop_watch_movie();
	}

}
