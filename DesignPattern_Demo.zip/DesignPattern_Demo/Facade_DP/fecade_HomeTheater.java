package Facade_DP;

public class fecade_HomeTheater {
	private TV tv;
	private Sound_SYS ss;
	private Room_Light rl;
	public fecade_HomeTheater(TV tv,Sound_SYS ss,Room_Light rl) {
		this.tv=tv;
		this.ss=ss;
		this.rl=rl;
	}
	public void watch_movie()
	{
		System.out.println("------Watching movies-------");
		tv.tv_on();
		ss.ss_on();
		rl.room_light_on();
	}
	public void stop_watch_movie()
	{
		System.out.println("------Stop Watching movies-------");
		tv.tv_off();
		ss.ss_off();
		rl.room_light_off();
	}

}
