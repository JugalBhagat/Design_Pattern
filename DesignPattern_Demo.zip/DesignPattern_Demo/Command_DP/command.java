package Command_DP;

interface command {
	public void execute();
}
