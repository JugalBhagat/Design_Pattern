package Command_DP;

public class main_class {
	public static void main(String args[]) {
		tubelight t=new tubelight();
		tubelightON ton=new tubelightON(t);
		Remote r=new Remote();
		r.setcommand(ton);
		r.press_BTN();
		
		tubelightOFF toff=new tubelightOFF(t);
		r.setcommand(toff);
		r.press_BTN();
		
		r.setcommand(ton);
		r.press_BTN();
	}
}
