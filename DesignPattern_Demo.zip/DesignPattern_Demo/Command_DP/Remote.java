package Command_DP;

public class Remote {
	command c;
	void setcommand(command c) {
		this.c=c;
	}
	void press_BTN()
	{
		c.execute();
	}
}
