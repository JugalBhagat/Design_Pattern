package Command_DP;

public class tubelightOFF implements command {
	tubelight tl;
	public tubelightOFF(tubelight tl) {
		this.tl=tl;
	}
	@Override
	public void execute() {
		tl.switchOFF();
	}

}
