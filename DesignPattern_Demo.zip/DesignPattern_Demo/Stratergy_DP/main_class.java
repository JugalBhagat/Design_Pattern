package Stratergy_DP;

public class main_class {

	public static void main(String[] args) {
		vehicel v=new offroad_vehicel();
		v.drive();
		
		vehicel v2=new sports_vehicel();
		v2.drive();

	}

}
