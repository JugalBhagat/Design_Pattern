package Stratergy_DP;

public class speed_feature implements drive_features{

	@Override
	public void feature() {
		System.out.println("Speedy performance");
		
	}

}
