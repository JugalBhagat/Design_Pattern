package Stratergy_DP;

public class offroad_vehicel extends vehicel {

	public offroad_vehicel() {
		super(new power_features());
	}

}
