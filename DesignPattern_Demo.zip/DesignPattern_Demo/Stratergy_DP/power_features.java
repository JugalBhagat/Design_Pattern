package Stratergy_DP;

public class power_features implements drive_features{

	@Override
	public void feature() {
		System.out.println("power performance");
		
	}

}
