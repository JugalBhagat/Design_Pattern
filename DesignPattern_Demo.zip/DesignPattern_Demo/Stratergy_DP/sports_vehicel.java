package Stratergy_DP;

public class sports_vehicel extends vehicel{

	public sports_vehicel() {
		super(new speed_feature());
	}

}
