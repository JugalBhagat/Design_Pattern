package Stratergy_DP;

public class vehicel {
	drive_features driveobj;
	public vehicel(drive_features obj) {
		this.driveobj=obj;
	}
	public void drive() {
		driveobj.feature();
	}
}