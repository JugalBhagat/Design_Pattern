package Abstract_Factory_DP;

public class Samsung_factory extends Phone_Store {

	@Override
	Phone create_phone(String model) {
		if(model.equals("S22"))
			return new S22();
		if(model.equals("Note20"))
			return new Note20();
		else
			return null;
	}

}
