package Abstract_Factory_DP;

public class Apple_factory extends Phone_Store{

	@Override
	Phone create_phone(String model) {
		if(model.equals("Iphone10"))
			return new Iphone10();
		else if(model.equals("Iphone14"))
			return new Iphone14();
		else
			return null;
	}
}
