package Abstract_Factory_DP;

public class S22 extends Phone{

	public S22() {
		brand="Samsung";
		model="S22";
		size="6.8";
	}

}
