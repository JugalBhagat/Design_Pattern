package Abstract_Factory_DP;

public class Note20 extends Phone{

	public Note20() {
		brand="Samsung";
		model="Note 20";
		size="6.5";
	}

}
