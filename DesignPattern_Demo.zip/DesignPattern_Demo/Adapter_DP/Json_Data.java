package Adapter_DP;

interface Json_Data {

		void read_json_data();
}
