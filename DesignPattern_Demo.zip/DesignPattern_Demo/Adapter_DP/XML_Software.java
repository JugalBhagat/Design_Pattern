package Adapter_DP;

public class XML_Software implements XML_data{

	@Override
	public void read_xml_data() {
	
		System.out.println("Reading XML data ..........");
		
	}

}
