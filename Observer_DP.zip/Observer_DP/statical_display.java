package Observer_DP;

public class statical_display implements observer{

	@Override
	public void update(double temp, double humd, double pres) {
		System.out.println("\nStatical Display:");
        System.out.println("Temperature: " + temp);
        System.out.println("Humidity: " + humd);
        System.out.println("Pressure: " + pres);
		
	}
	public String tostr()
	{
		return "statical_obj";
	}
}
