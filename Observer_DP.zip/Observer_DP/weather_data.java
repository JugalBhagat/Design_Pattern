package Observer_DP;

import java.util.ArrayList;
import java.util.List;

public class weather_data implements subject {

	private List<observer> os;
	private double temp;
	private double humd;
	private double pres;
	
	public weather_data()
	{
		os=new ArrayList<>();
		System.out.println("observer_list is created");
	}
	@Override
	public void attach(observer o) {
		os.add(o);
		System.out.println(o.getClass()+" has been attached");
	}

	@Override
	public void detach(observer o) {
		os.remove(o);
		System.out.println(o.getClass()+" has been detach");
	}

	@Override
	public void notify_observer() {
		System.out.println("observer is nofied");
		for(observer o:os) {
			o.update(temp, humd, pres);
		}
	}
	
	public void mesurement_chaged() {
		System.out.println("mesurement is changed");
		notify_observer();
	}
	
	public void set_mesurement(double temp,double humd,double pres) {
		System.out.println("setting mesurement");
		this.humd=humd;
		this.temp=temp;
		this.pres=pres;
		mesurement_chaged();
	}
	
	public double get_temp() {
	    return temp;
	}

    public double get_humd() {
        return humd;
    }

    public double get_pres() {
        return pres;
    }
}
