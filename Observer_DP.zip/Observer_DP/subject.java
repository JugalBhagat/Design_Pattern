package Observer_DP;

interface subject {
	void attach(observer o);
	void detach(observer o);
	void notify_observer();
}
