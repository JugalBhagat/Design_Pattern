package Observer_DP;

public interface observer {
	void update(double temp,double humd,double pres);
}
