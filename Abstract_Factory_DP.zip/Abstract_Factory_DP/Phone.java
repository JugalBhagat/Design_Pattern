package Abstract_Factory_DP;

public abstract class Phone {
	String brand;
	String model;
	String size;
	void build_phone()
	{
		System.out.println("brand name: "+brand);
		System.out.println("model name: "+model);
		System.out.println("size name: "+size);
	}
	void assemble()
	{
		System.out.println("Assembleing all parts......");
	}
	void packbox()
	{
		System.out.println("Packing......");
	}
}
