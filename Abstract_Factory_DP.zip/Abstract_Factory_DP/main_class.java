package Abstract_Factory_DP;

public class main_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Phone_Store iphone=new Apple_factory();
		iphone.order_phone("Iphone14");
		
		Phone_Store s=new Samsung_factory();
		s.order_phone("Note20");
	}

}
