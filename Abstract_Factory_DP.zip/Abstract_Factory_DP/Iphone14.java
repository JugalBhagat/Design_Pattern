package Abstract_Factory_DP;

public class Iphone14 extends Phone{
	public Iphone14()
	{
		brand="Apple";
		model="10";
		size="6";
	}

}
