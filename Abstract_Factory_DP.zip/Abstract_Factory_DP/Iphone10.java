package Abstract_Factory_DP;

public class Iphone10 extends Phone {
	public Iphone10()
	{
		brand="Apple";
		model="10";
		size="6";
	}
}
