package Abstract_Factory_DP;

public abstract class Phone_Store {
	public Phone order_phone(String model)
	{
		Phone p;
		p=create_phone(model);
		p.build_phone();
		p.assemble();
		p.packbox();
		return p;
	}
	abstract Phone create_phone(String model);
}
