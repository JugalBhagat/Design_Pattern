package Decorator_DP;

public class main_class {

	public static void main(String[] args) {
		TextComponant plaintext=new plain_text("Hello");
		
		TextComponant bold=new Bold_text(plaintext);
		TextComponant italic=new Italic_text(plaintext);
		
		System.out.println("plain text"+plaintext.render());
		System.out.println("plain text"+bold.render());
		System.out.println("plain text"+italic.render());
	}

}
