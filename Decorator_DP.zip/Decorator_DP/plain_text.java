package Decorator_DP;

public class plain_text implements TextComponant {
	private String text;
	public plain_text(String text) {
		this.text=text;
	}
	@Override
	public String render() {
		// TODO Auto-generated method stub
		return text;
	}

}
