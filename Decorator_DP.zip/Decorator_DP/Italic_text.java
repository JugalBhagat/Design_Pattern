package Decorator_DP;

public class Italic_text extends Text_Decorator {

	public Italic_text(TextComponant tc) {
		super(tc);
	}
	public String render()
	{
		return "<i>"+super.render()+"</i>";
	}
}
